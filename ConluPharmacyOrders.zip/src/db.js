const mysql=require('mysql2/promise');
const config={host:process.env.DB_HOST||'localhost',port:Number(process.env.DB_PORT||3306),user:process.env.DB_USER||'root',password:process.env.DB_PASSWORD||'',database:process.env.DB_NAME||'conlu_pharmacy',waitForConnections:true,connectionLimit:10};
const pool=mysql.createPool(config);
async function initDb(){
 const c=await mysql.createConnection({host:config.host,port:config.port,user:config.user,password:config.password});
 await c.query(`CREATE DATABASE IF NOT EXISTS \`${config.database.replace(/`/g,'')}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`); await c.end();
 await pool.query(`CREATE TABLE IF NOT EXISTS administrators(id INT AUTO_INCREMENT PRIMARY KEY,username VARCHAR(80) UNIQUE NOT NULL,password_hash VARCHAR(255) NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)`);
 await pool.query(`CREATE TABLE IF NOT EXISTS customers(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(160) NOT NULL,email VARCHAR(190) UNIQUE NOT NULL,phone VARCHAR(40),password_hash VARCHAR(255) NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)`);
 await pool.query(`CREATE TABLE IF NOT EXISTS orders(id BIGINT AUTO_INCREMENT PRIMARY KEY,customer_id INT NOT NULL,status ENUM('pending','confirmed','processing','completed','cancelled') DEFAULT 'pending',total DECIMAL(10,2) NOT NULL,phone VARCHAR(40),delivery_address VARCHAR(500),payment_method ENUM('cash_on_delivery','pickup') DEFAULT 'cash_on_delivery',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,FOREIGN KEY(customer_id) REFERENCES customers(id))`);
 await pool.query(`CREATE TABLE IF NOT EXISTS order_items(id BIGINT AUTO_INCREMENT PRIMARY KEY,order_id BIGINT NOT NULL,medicine_id INT NOT NULL,medicine_name VARCHAR(180) NOT NULL,quantity INT NOT NULL,unit_price DECIMAL(10,2) NOT NULL,FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,FOREIGN KEY(medicine_id) REFERENCES medicines(id))`);
 await pool.query(`CREATE TABLE IF NOT EXISTS categories(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) UNIQUE NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)`);
 await pool.query(`CREATE TABLE IF NOT EXISTS medicines(id INT AUTO_INCREMENT PRIMARY KEY,code VARCHAR(80) UNIQUE,name VARCHAR(180) NOT NULL,brand VARCHAR(120),description TEXT,category_id INT,price DECIMAL(10,2) NOT NULL DEFAULT 0,stock INT NOT NULL DEFAULT 0,reorder_level INT NOT NULL DEFAULT 10,expiration_date DATE,image VARCHAR(255),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE SET NULL)`);
 await pool.query(`CREATE TABLE IF NOT EXISTS inventory_transactions(id BIGINT AUTO_INCREMENT PRIMARY KEY,medicine_id INT NOT NULL,admin_id INT,transaction_type ENUM('stock_in','stock_out','adjustment') NOT NULL,quantity INT NOT NULL,reference VARCHAR(120),notes VARCHAR(1000),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(medicine_id) REFERENCES medicines(id) ON DELETE CASCADE,FOREIGN KEY(admin_id) REFERENCES administrators(id) ON DELETE SET NULL)`);
 const [admins]=await pool.query('SELECT id FROM administrators LIMIT 1');
 if(!admins.length){const bcrypt=require('bcryptjs');await pool.query('INSERT INTO administrators(username,password_hash) VALUES(?,?)',['admin',await bcrypt.hash('Admin123!',10)]);}
 const [cats]=await pool.query('SELECT id FROM categories LIMIT 1');
 if(!cats.length){for(const n of ['Pain Relievers','Antibiotics','Vitamins and Supplements','Cough and Cold Medicines','Allergy Medicines','First Aid','Maintenance Medicines','Other Medicines']) await pool.query('INSERT IGNORE INTO categories(name) VALUES(?)',[n]);}
 const [meds]=await pool.query('SELECT id FROM medicines LIMIT 1');
 if(!meds.length){const [cs]=await pool.query('SELECT id,name FROM categories');const cid=Object.fromEntries(cs.map(x=>[x.name,x.id]));
 const demo=[
 ['MED-001','Paracetamol 500 mg','Biogesic','For temporary relief of fever and mild pain.','Pain Relievers',5.50,120,20,'2027-12-31','https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=700&q=80'],
 ['MED-002','Vitamin C 500 mg','Ceelin','Vitamin supplement. Follow the product label.','Vitamins and Supplements',8.00,85,15,'2028-06-30','https://images.unsplash.com/photo-1556229010-6c3f2c9ca5f8?auto=format&fit=crop&w=700&q=80'],
 ['MED-003','Cetirizine 10 mg','Allerta','Antihistamine for allergy symptoms.','Allergy Medicines',4.00,0,10,'2027-09-30','https://images.unsplash.com/photo-1587854692152-cbe660dbde88?auto=format&fit=crop&w=700&q=80'],
 ['MED-004','Amoxicillin 500 mg','Generic','Prescription antibiotic. Use only as directed by a licensed professional.','Antibiotics',12.00,45,10,'2027-08-31','https://images.unsplash.com/photo-1585435557343-3b092031a831?auto=format&fit=crop&w=700&q=80'],
 ['MED-005','Cough Relief Syrup','Generic','Cough relief product. Read label and consult a pharmacist.','Cough and Cold Medicines',75.00,8,12,'2027-05-31','https://images.unsplash.com/photo-1603398938378-e54eab446029?auto=format&fit=crop&w=700&q=80']];
 for(const m of demo) await pool.query('INSERT INTO medicines(code,name,brand,description,category_id,price,stock,reorder_level,expiration_date,image) VALUES(?,?,?,?,?,?,?,?,?,?)',[m[0],m[1],m[2],m[3],cid[m[4]],m[5],m[6],m[7],m[8],m[9]]);
 }
}
module.exports={pool,initDb};
