# Conlu Pharmacy Portal Admin System

Node.js + Express + MySQL + EJS + Bootstrap. Public users can search and view medicine information; admin routes require login.

## Requirements
- Node.js 18+ (20 LTS recommended)
- XAMPP or MySQL Server
- Visual Studio Code

## Run in VS Code
1. Extract this ZIP.
2. Open the `Conlu_Pharmacy_Portal` folder in VS Code.
3. Copy `.env.example` to `.env`; edit DB user/password if needed.
4. Start MySQL in XAMPP.
5. Open Terminal in this folder and run:
   ```bash
   npm install
   npm start
   ```
6. Open `http://localhost:3000`.

On first startup the app creates the `conlu_pharmacy` database, tables, categories, demo medicines, and an administrator.

## Demo admin
- Username: `admin`
- Password: `Admin123!`

Change the demo password before using this outside a classroom/demo environment. This starter uses Express session memory storage; use a persistent session store and HTTPS in production.

## Features
- Public catalog search by medicine name, brand, category, or code
- Medicine detail pages and stock status
- Admin dashboard statistics and inventory value
- Medicine create/edit/delete and image upload (PNG/JPG/WEBP/GIF, 3 MB max)
- Category management
- Stock-in / stock-out with transaction history and SQL row locking
- Low stock and out-of-stock indicators

## Notes
- Sample products use individual remote image URLs. Uploaded images are stored in `public/uploads`.
- Medicine data is persisted in MySQL, not browser storage.
- Educational demo only. This is not a prescription, dispensing, or patient-record system.

## Customer ordering update
Customer registration/login, session cart, checkout, customer order history, admin customer list, and admin order status management are included. Orders reduce stock transactionally when submitted. Demo admin remains `admin` / `Admin123!`. Public customer registration is at `/customer/register`.
